package com.example.bookservice;
public class Book {
    private final int id;
    private final String name;

    public Book(final int id,  final String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}