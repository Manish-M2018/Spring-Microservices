package com.example.bookservice;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
@RequestMapping("/books")
@RestController
public class BookController {
    private List<Book> books = Arrays.asList(
            new Book(1, "Joe Bloggs"),
            new Book(2, "Jane Doe"));
    
    @GetMapping
    public List<Book> getAllBooks() {
        return books;
    }
    
    @GetMapping("/{id}")
    public Book getCustomerById(@PathVariable int id) {
        return books.stream()
                        .filter(book -> book.getId() == id)
                        .findFirst()
                        .orElseThrow(IllegalArgumentException::new);
    }
}